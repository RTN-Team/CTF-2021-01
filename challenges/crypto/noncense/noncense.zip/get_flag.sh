#!/bin/sh
scp -i key_file.pem vgtables@smoothie.rtn-team.cc:/home/vgtables/secret_document.pdf flag.pdf
